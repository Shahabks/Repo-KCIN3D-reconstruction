﻿using System;
using Autodesk.AutoCAD.ApplicationServices;
using Autodesk.AutoCAD.DatabaseServices;
using Autodesk.AutoCAD.EditorInput;
using Autodesk.AutoCAD.Runtime;
using Autodesk.Civil.DatabaseServices;

namespace _3DE2S
{
    public class Class1
    {
        [LispFunction("CreateSurfaceFromFace")]
        public static void CreateSurfaceFromFace(ResultBuffer resultBufferArguments)
        {
            DocumentLock documentLock = Autodesk.AutoCAD.ApplicationServices.Application.DocumentManager.MdiActiveDocument.LockDocument();
            using (documentLock)
            {
                Database database = Autodesk.AutoCAD.ApplicationServices.Application.DocumentManager.MdiActiveDocument.Database;

                using (Transaction transaction = database.TransactionManager.StartTransaction())
                {
                    ObjectId surfaceId = TinSurface.Create(database, "TestSurface");
                    TinSurface surface = surfaceId.GetObject(OpenMode.ForWrite) as TinSurface;

                    surface.DrawingObjectsDefinition.AddFrom3DFaces(GetAll3DFaceEntities(), true, "");

                    transaction.Commit();
                    Autodesk.AutoCAD.ApplicationServices.Application.DocumentManager.MdiActiveDocument.Editor.UpdateScreen();
                }
            }
        }

        public static ObjectIdCollection GetAll3DFaceEntities()
        {
            Document document = Autodesk.AutoCAD.ApplicationServices.Application.DocumentManager.MdiActiveDocument;
            Editor editor = document.Editor;

            TypedValue[] typedValues;

            typedValues = new TypedValue[] { new TypedValue((int)DxfCode.Start, "3DFACE") };

            SelectionFilter selectionFilter = new SelectionFilter(typedValues);
            PromptSelectionResult promptSelectionResult = editor.SelectAll(selectionFilter);

            if (promptSelectionResult.Status == PromptStatus.OK)
            {
                return new ObjectIdCollection(promptSelectionResult.Value.GetObjectIds());
            }
            else
            {
                return new ObjectIdCollection();
            }

        }

    }
}
